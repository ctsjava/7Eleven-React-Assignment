import React, { Component } from 'react';
import { render } from 'react-dom';
import './style.css';
import 'bootstrap/dist/css/bootstrap.min.css';

class App extends Component {
  constructor() {
    super();
    this.state = {
      labelOne: '+10',
      labelTwo: '+20',
      labelThree: '-5',
      labelFour: '-10',
      buttonOne: 0,
      buttonTwo: 0,
      buttonThree: 0,
      buttonFour: 0,
      result: 0
    };
  }

  handleClickOne = (button) => {
    switch(button) {
      case 'b1':
      this.setState(({ buttonOne,result }) => ({
        buttonOne: ++buttonOne ,
        result :result +10
        }));
        
        break;
        case 'b2':
      this.setState(({ buttonTwo,result }) => ({
        buttonTwo: ++buttonTwo ,
        result : result +20
        }));
        
        break;
        case 'b3':
      this.setState(({ buttonThree,result }) => ({
        buttonThree: buttonThree + 1,
        result : result -5
        }));
        
        break;
        case 'b4':
      this.setState(({ buttonFour,result }) => ({
        buttonFour: buttonFour + 1,
        result : result -10
        }));
        
        break;
    }
    
  };


  render() {
    return (
      <div class="card">
      <h2 class="counter_app">Counter APP</h2>
        <div class="row mt-3">
          <div class="col-lg add">
            <div role="group" aria-label="First group">
              <label class="number">{this.state.labelOne}</label>
              <button type="button" class="btn btn-primary"  onClick={() => this.handleClickOne('b1')}>{this.state.buttonOne}</button>
              <label class="number">{this.state.labelTwo}</label>
              <button type="button" class="btn btn-primary" onClick={() => this.handleClickOne('b2')}>{this.state.buttonTwo}</button>
              <label class="number">{this.state.labelThree}</label>
              <button type="button" class="btn btn-primary" onClick={() => this.handleClickOne('b3')}>{this.state.buttonThree}</button>
              <label class="number">{this.state.labelFour}</label>
              <button type="button" class="btn btn-primary" onClick={() => this.handleClickOne('b4')}>{this.state.buttonFour}</button></div>
              <hr></hr>
              <h2>Total Count :&nbsp;
              <label class="output"> {this.state.result} </label>
              </h2>
            
        </div>
        </div>
      </div>
    );
  }
}

render(<App />, document.getElementById('root'));
